
package Capitulo2;

import java.util.Scanner;

public class Ejercicio13 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la cantidad guardada mensualmente; ");
        double cantidad = entrada.nextDouble();
        double IntMen = 0.00417;
       
		double total = 100 * (1 + IntMen);
		
		total = (100 + total) * (1 + IntMen);
		
		total = (100 + total) * (1 + IntMen);
		
		total = (100 + total) * (1 + IntMen);
		
		total = (100 + total) * (1 + IntMen);
		
		total = (100 + total) * (1 + IntMen);
                
                System.out.println("Luego de 6 meses el valor en la cuenta es: " + total);
    }
    
}
