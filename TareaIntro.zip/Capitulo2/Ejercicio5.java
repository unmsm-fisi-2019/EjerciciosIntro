
package Capitulo2;

import java.util.Scanner;

public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el subtotal: ");
        int Subtotal = entrada.nextInt();
        System.out.println("El porcentaje (en decimales) a aunmentar: ");
        double PorcentajeGrati = entrada.nextDouble();
        double Total = Subtotal + Subtotal*PorcentajeGrati;
        System.out.println("El monto final recibido es: " + Total);
        
    }
    
}
