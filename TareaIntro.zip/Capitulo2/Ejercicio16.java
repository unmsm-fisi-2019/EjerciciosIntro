
package Capitulo2;

import java.util.Scanner;

public class Ejercicio16 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el lado del hexágono: ");
        double lado = entrada.nextDouble();
        double Area = ((3 * Math.pow(3, 0.5))*Math.pow(lado, 2))/2;
        System.out.println("El área del hexágono es: " + Area);
    }
    
}
