
package Capitulo2;

import java.util.Scanner;

public class Ejercicio20 {
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese el balance y el porcentaje de interés: ");
        double balance = entrada.nextDouble();
        double PorcInteres = entrada.nextDouble();
        double interes = balance * (PorcInteres/1200);
        System.out.println("El interés es: " + interes);
        
    }
    
}
