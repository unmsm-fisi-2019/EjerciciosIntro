
package Capitulo2;

import java.util.Scanner;
public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double area,volumen;
        double pi=3.14159;
        System.out.println("Ingrese el radio: ");
        double radio=entrada.nextDouble();
        System.out.println("Ingrese la longitud del cilindro: ");
        double longitud=entrada.nextDouble();
        area=radio*radio*pi;
        volumen=area*longitud;
        System.out.println("El area es: "+area);
        System.out.println("El volumen es: "+volumen);
    }
}
