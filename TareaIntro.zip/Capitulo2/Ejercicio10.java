
package Capitulo2;
import java.util.Scanner;
public class Ejercicio10 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double energia;
        System.out.println("Ingresa la cantidad de agua en kg: ");
        double cantidad=entrada.nextDouble();
        System.out.println("Ingresa la temperatura inicial: ");
        double TempIni=entrada.nextDouble();
        System.out.println("Ingresa la temperarura final: ");
        double TempFin=entrada.nextDouble();
        energia = cantidad*(TempFin-TempIni)*4184;
        System.out.println("La energia requerida es: " + energia);

}
}