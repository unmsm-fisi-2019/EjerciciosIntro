
package Capitulo2;

import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double Farenheit;
        System.out.println("Escribe el número de grados celsius: ");
        double Celsius = entrada.nextDouble();
        Farenheit = (9.0/5.0)*Celsius + 32;
        System.out.println("El número de grados en Farenheit es: " + Farenheit);
        
    }
    
}
