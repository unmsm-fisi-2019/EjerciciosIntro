
package Capitulo2;

import java.util.Scanner;

public class Ejercicio15 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingrese X1 y Y1: ");
        double X1 = entrada.nextDouble();
        double Y1 = entrada.nextDouble();
        System.out.print("Ingrese X2 y Y2: ");
        double X2 = entrada.nextDouble();
        double Y2 = entrada.nextDouble();
        double Suma = Math.pow(X2 - X1, 2) + Math.pow(Y2 - Y1, 2);
        double distancia = Math.pow(Suma , 0.5);
        System.out.println("La distancia entre los 2 puntos es: " + distancia);
    }
    
}
