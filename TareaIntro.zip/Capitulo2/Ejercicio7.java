
package Capitulo2;

import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de minutos: ");
        int minutos = entrada.nextInt();
        
        int años = minutos/(365 * 24 * 60);
        int dias =(minutos % 525600)/(60*24);
        System.out.println("En un año hay " + años + " años y " + dias + " dias ");
        
    }
    
}
