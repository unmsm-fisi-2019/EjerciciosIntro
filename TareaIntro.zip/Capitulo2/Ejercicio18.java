
package Capitulo2;

import java.util.Scanner;

public class Ejercicio18 {
    public static void main(String[] args) {
        System.out.println("a \t b \t pow(a,b)");
        
        for(int i=1; i<=5; i++){
            int j = i + 1;
            double k = Math.pow(i,j);
            System.out.println(i + "\t" + j + "\t" + k);
        }
    }
        
}
