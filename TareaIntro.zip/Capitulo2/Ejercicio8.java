
package Capitulo2;
import java.util.Scanner;
public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Ingrese el desplazamiento del tiempo (en GMT) en su zona horaria: ");
	int despla = entrada.nextInt();
        
	long totalMiliseg = System.currentTimeMillis();

	long totalSeg = totalMiliseg / 1000;

	long segundosAct = totalSeg % 60;
        
	long totalMin = totalSeg / 60;

	long minutosAct = totalMin % 60;

	long totalHoras = totalMin / 60;

	long horaAct = totalHoras % 24;
	horaAct = horaAct + despla;

	System.out.println("El tiempo actual es " + horaAct + " : "+ minutosAct + " : " + segundosAct);
    }
    
}

        
        
        
    


