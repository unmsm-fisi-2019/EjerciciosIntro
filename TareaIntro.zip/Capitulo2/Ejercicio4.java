
package Capitulo2;
import java.util.Scanner;
public class Ejercicio4 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese un numero en libras: ");
        double num1 = entrada.nextDouble();
        double num2 = num1 * 0.454;
        System.out.println("El numero en kilogramos es: " + num2);
    }
}
