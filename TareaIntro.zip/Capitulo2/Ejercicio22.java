
package Capitulo2;

import java.util.Scanner;

public class Ejercicio22 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingresar un monto: ");
        double monto = entrada.nextDouble();
        int monto2 = (int)(monto * 100);
        System.out.println("El monto " + monto2 + " representa: ");
        int dolares = monto2 / 100;
        monto2 = monto2 % 100;
        int centavos = monto2;
        System.out.println(" " + dolares + " dolares");
        System.out.println(" " + centavos + " centavos");
    }
    
}
