
package Capitulo2;
import java.util.Scanner;
public class Ejercicio9 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double aceleracion;
        System.out.println("Ingrese Vinicial,Vfinal y tiempo: ");
        double vi=entrada.nextDouble();
        double vf=entrada.nextDouble();
        double t=entrada.nextDouble();
        aceleracion=(vf-vi)/t;
        System.out.println("La aceleracion promedio es: "+aceleracion);
}
}