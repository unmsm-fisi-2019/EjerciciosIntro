
package Capitulo2;


public class Ejercicio11 {
    public static void main(String[] args) {
        int poblacion = 312032486;
        int año = 5;
        int dias = año * 365;
        int horas = dias * 24;
        int minutos = horas * 60;
        int segundos = minutos * 60;
        double nacimientos = segundos/7;
        double muertes = segundos/13;
        double inmigrantes = segundos/45;
        double Poblacion = poblacion + nacimientos + inmigrantes - muertes;
        System.out.println("La población en 5 años será: " + Poblacion);
          
    }
    
    
    
}
