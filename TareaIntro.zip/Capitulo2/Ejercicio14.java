
package Capitulo2;

import java.util.Scanner;

public class Ejercicio14 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese su peso en libras: ");
        double peso = entrada.nextDouble();
        System.out.println("Ingrese su talla en pulgadas: ");
        double talla = entrada.nextDouble();
        double talla2 = talla * 0.0254;
        double IMC = peso * 0.4536/(talla2 * talla2);
        System.out.println("Su índice de masa corporal es: " + IMC);
    }
    
}
