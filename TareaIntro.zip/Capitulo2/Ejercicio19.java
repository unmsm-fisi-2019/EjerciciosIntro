
package Capitulo2;

import java.util.Scanner;

public class Ejercicio19 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese los 3 puntos del triángulo: ");
        double X1 = entrada.nextDouble();
        double Y1 = entrada.nextDouble();
        double X2 = entrada.nextDouble();
        double Y2 = entrada.nextDouble();
        double X3 = entrada.nextDouble();
        double Y3 = entrada.nextDouble();
        double suma1 = Math.pow(X2 - X1, 2) + Math.pow(Y2 - Y1, 2);
        double lado1 = Math.pow(suma1 , 0.5);
        double suma2 = Math.pow(X3 - X1, 2) + Math.pow(Y3 - Y1, 2);
        double lado2 = Math.pow(suma2 , 0.5);
        double suma3 = Math.pow(X2 - X3, 2) + Math.pow(Y2 - Y3, 2);
        double lado3 = Math.pow(suma3 , 0.5);
        double SemiP = (lado1 + lado2 + lado3)/2;
        double area = SemiP*(SemiP-lado1)*(SemiP-lado2)*(SemiP-lado3);
        double areaF = Math.pow(area, 0.5);
        System.out.println("El área del triángulo es: " + areaF);
        
    }
    
}
