
package Capitulo2;

import java.util.Scanner;

public class Ejercicio23 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la distancia recorrida: ");
        double distancia = entrada.nextDouble();
        System.out.println("Ingrese las millas por galón: ");
        double millas = entrada.nextDouble();
        System.out.println("Ingrese el precio por galón: ");
        double precio = entrada.nextDouble();
        double CostoViaje = (distancia/millas)*precio;
        System.out.println("El costo del viaje es: " + CostoViaje);
        
    }
    
}
