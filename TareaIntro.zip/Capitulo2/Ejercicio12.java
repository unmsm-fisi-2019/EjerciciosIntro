
package Capitulo2;

import java.util.Scanner;

public class Ejercicio12 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la velocidad y la acelaración: ");
        double velocidad = entrada.nextDouble();
        double aceleracion = entrada.nextDouble();
        double altura = velocidad*velocidad/(2*aceleracion);
        System.out.println("La mínima altura para el avión es: " + altura);
    }
    
}
