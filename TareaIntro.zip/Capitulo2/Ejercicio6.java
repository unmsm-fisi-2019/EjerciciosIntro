
package Capitulo2; 

import java.util.Scanner;

public class Ejercicio6 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int n1,n2,n3;
        int suma;
        System.out.println("Ingrese un número entre 0 y 1000: ");
        int numero = entrada.nextInt();
            n1=numero%10;
            n2=(numero/10)/10;
            n3=(numero/10)%10;
            suma=n1+n2+n3;
        System.out.println("La suma de dígitos es: " + suma );
    }   
}
