
package Capitulo2;

import java.util.Scanner;

public class Ejercicio17 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la temperatura en Farenheit entre -58°F y 41°F: ");
        double temperatura = entrada.nextDouble();
        System.out.println("Ingrese la velocidad de los vientos (>=2) en millas por hora: ");
        double velocidad = entrada.nextDouble();
        double indice = 35.74 + 0.6215*temperatura - 35.75*Math.pow(velocidad, 0.16) + 0.4275*temperatura*Math.pow(velocidad, 0.16);
        System.out.println("El índice de viento helado es: " + indice);
    }
}
