
package Capitulo2;

import java.util.Scanner;

public class Ejercicio21 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la cantidad a invertir: ");
        double cantidad = entrada.nextDouble();
        System.out.println("Ingrese el interés anual en porcentaje: ");
        double interes = entrada.nextDouble();
        System.out.println("Ingrese la cantidad de años: ");
        double años = entrada.nextDouble();
        double ValorFut = cantidad * Math.pow((1 + (interes/1200)),(años*12));
        System.out.println("El valor acumulado es: " + ValorFut);
    }
    
}
