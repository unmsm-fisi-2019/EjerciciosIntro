
package Capitulo2;
import java.util.Scanner;
public class Ejercicio3 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la distancia en pies: ");
        double distancia1 = entrada.nextDouble();
        double distancia2 = distancia1*0.305;
        System.out.println("La distancia en metros es: " + distancia2);
    }
    
}
