package Capitulo1;

public class Ejercicio5 {
    public static void main(String[] args) {
        
        double n; 
        n = (9.5 * 4.5 - 2.5 * 3)/(45.5 - 3.5);
        System.out.println("El resultado es: " + n );
    }
}

