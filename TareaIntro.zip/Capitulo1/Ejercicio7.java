package Capitulo1;

public class Ejercicio7 {
    public static void main(String[] args) {
        double Pi1, Pi2;
        Pi1 = 4*(1.0 - 1.0/3.0 + 1.0/5.0 - 1.0/7.0 + 1.0/9.0 - 1.0/11.0);
        System.out.println("El primer valor aproximado de Pi es: " + Pi1);
        Pi2 = 4*(1.0 - 1.0/3.0 + 1.0/5.0 - 1.0/7.0 + 1/9.0 - 1.0/11.0 + 1.0/13.0);
        System.out.println("El segundo valor aproximado de Pi es: " + Pi2);
    }
}

