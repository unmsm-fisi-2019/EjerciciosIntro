package Capitulo1;

public class Ejercicio9 {
    public static void main(String[] args) {
        double Ancho = 4.5;
        double Largo = 7.9;
        double Area = Ancho * Largo;
        System.out.println("El área del rectángulo es: " + Area);
    }
    
}
