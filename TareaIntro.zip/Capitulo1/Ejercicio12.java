
package Capitulo1;


public class Ejercicio12 {
    public static void main(String[] args) {
        int millas = 24;
        double horas = 1.0;
        double minutos = 40.0;
        double segundos = 35.0;
        double distancia = millas * 1.6;
        double tiempo = (horas*3600 + minutos*60 + segundos)/3600.0;
        double velocidad = distancia/tiempo;
        System.out.println("La velocidad en kilometros por hora es: " + velocidad);
    }

}
