
package Capitulo1;


public class Ejercicio11 {
    public static void main(String[] args) {
        int poblacion, nacimiento ,muertes ,inmigrantes,actual, Naum;
    poblacion = 312032486;
    nacimiento = (3153600/7);
    muertes = (3153600/13);
    inmigrantes =(3153600/45);
    actual = nacimiento - muertes + inmigrantes;
    for(int i=1;i<6;i++){
        Naum= actual * i;
        poblacion = poblacion + Naum;
        System.out.print("Para año " + i);
        System.out.println("\nLa población es: " + poblacion);
    }
    
}
}