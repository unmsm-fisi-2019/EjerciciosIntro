package Capitulo1;

public class Ejercicio4 { 
    public static void main(String[] args) {
        System.out.println("a \t a^2 \t a^3");
        for(int i=1; i<=4; i++){
            System.out.println(i + "\t" + i * i + "\t" + i * i * i);
        }
        
    }
    
}
