
package Capitulo1;

public class Ejercicio13 {
    public static void main(String[] args) {
        double a = 3.4, b = 50.2, c = 2.1, d = 55, e = 44.5, f = 5.9;
        double x, y;
        x = (e*d - b*f)/(a*d - b*c);
        y = (a*f - b*c)/(a*d - b*c);
        System.out.println("3.4x + 50.2y = 44.5 \n2.1x + 55y = 5.9");
        System.out.println("El valor de x es " + x);
        System.out.println("El valor de y es: " + y);
    }
    
}
