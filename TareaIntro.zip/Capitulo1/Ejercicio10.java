
package Capitulo1;


public class Ejercicio10 {
    public static void main(String[] args) {
        int distancia = 14;
        double dist = distancia / 1.6;
        double min = 45.0;
        double seg = 30.0;
        double tiempo = ((min*60 + seg)/3600);
        double velocidad = dist/tiempo;
        System.out.println("La velocidad en millas por hora es: " + velocidad);
       
        
    }
    
}
