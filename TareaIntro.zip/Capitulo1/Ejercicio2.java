package Capitulo1;

public class Ejercicio2 {
    public static void main(String[] args) {
        int i;
        for( i=0; i<5; i++){
        System.out.println("Welcome to Java.");
     }
    }
    
}

