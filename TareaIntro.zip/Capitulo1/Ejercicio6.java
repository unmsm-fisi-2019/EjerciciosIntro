package Capitulo1;

public class Ejercicio6 {
    public static void main(String[] args) {
        int i, suma = 0 ;
        for(i = 1; i<=9; i++){
         suma = suma + i;
        System.out.println("La suma de los 9 primeros digitos es: " + suma);
        }    
        
    }
    
}
