package Capitulo1;


public class Ejercicio1 {

    public static void main(String[] args) {
        System.out.println("Welcome to JAVA.");
        System.out.println("Welcome to computer science.");
        System.out.println("Porgramming is fun.");
    }
    
}

