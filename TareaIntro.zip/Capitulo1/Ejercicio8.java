package Capitulo1;



public class Ejercicio8 {
    public static void main(String[] args) {
        double pi;
        double Perimetro, Area;
        double radio = 5.5;
        pi = 3.14;
        Area = pi * radio * radio;
        Perimetro = 2 * pi * radio;
        System.out.println("El área del círculo es: " + Area);
        System.out.println("Y su perímetro es: " + Perimetro);
    }
}
